## Overview

This directory contains more advanced examples of how to use ActiveMQ's OpenWire based JMS API.